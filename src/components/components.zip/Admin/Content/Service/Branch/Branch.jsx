import React from "react";

const Branch = () => {
  return <div>Branch</div>;
};

export default Branch;
